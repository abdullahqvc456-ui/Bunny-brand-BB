import Safepay from "@sfpy/node-core";

/**
 * Safepay hosted checkout session creation.
 * Credentials stay on the server. Payment confirmation must come from a verified webhook,
 * never from a redirect query parameter.
 */
export async function createSafepayCheckout({ amountPaisa, orderNumber }) {
  const secret = process.env.SAFEPAY_SECRET_KEY;
  const merchantApiKey = process.env.SAFEPAY_MERCHANT_API_KEY;
  if (!secret || !merchantApiKey) {
    const err = new Error("Safepay is not configured yet. Add sandbox API credentials to environment variables.");
    err.status = 503;
    throw err;
  }

  const host = process.env.SAFEPAY_HOST || "https://sandbox.api.getsafepay.com";
  const client = Safepay(secret, { authType: "secret", host });

  // Safepay expects the smallest currency denomination; PKR uses paisa.
  const session = await client.payments.session.setup({
    merchant_api_key: merchantApiKey,
    intent: process.env.SAFEPAY_INTENT || "CYBERSOURCE",
    mode: process.env.SAFEPAY_MODE || "payment",
    currency: "PKR",
    amount: amountPaisa,
    metadata: { order_id: orderNumber, source: "bunny-brand-bb" }
  });

  const tracker = session?.tracker?.token;
  if (!tracker) throw new Error("Safepay did not return a payment tracker.");

  // Safepay's checkout URL is generated from the tracker plus a short-lived auth token.
  // Keep the URL-generation flow aligned with the current SDK/docs for your account.
  // This intentionally fails closed rather than guessing a checkout URL.
  if (typeof client.auth?.authenticationToken !== "function") {
    const err = new Error("Safepay tracker created. Complete checkout URL generation using the current @sfpy/node-core SDK guide before enabling online payments.");
    err.status = 503;
    err.tracker = tracker;
    throw err;
  }
  const auth = await client.auth.authenticationToken();
  const token = auth?.data || auth?.token;
  if (!token) throw new Error("Safepay authentication token was not returned.");

  const checkoutHost = process.env.SAFEPAY_CHECKOUT_HOST || host;
  const checkoutUrl = `${checkoutHost}/checkout/pay/${tracker}?token=${encodeURIComponent(token)}`;
  return { tracker, checkoutUrl };
}

/**
 * SECURITY TODO before production:
 * Safepay signs webhook payloads with HMAC. Implement verification against the exact
 * signature header and canonical payload format documented for your Safepay account.
 * This route deliberately rejects events until that verifier is configured.
 */
export function verifySafepayWebhook(_rawBody, _signatureHeader) {
  if (!process.env.SAFEPAY_WEBHOOK_SECRET) return false;
  // Do not assume a header name/encoding. Confirm the exact current Safepay webhook
  // signature format in the dashboard/docs, then implement and test HMAC verification.
  return false;
}
