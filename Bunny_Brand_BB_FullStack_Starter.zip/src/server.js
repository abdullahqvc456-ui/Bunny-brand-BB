import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { prisma } from "./db.js";
import { cookieOptions, signSession, requireAuth, requireAdmin } from "./security.js";
import { createSafepayCheckout, verifySafepayWebhook } from "./safepay.js";

const app = express();
app.set("trust proxy", 1);
app.use(helmet());
app.use(cors({
  origin: process.env.APP_ORIGIN || "http://localhost:3000",
  credentials: true
}));
app.use(cookieParser());

// Keep a raw copy for webhook signature verification. Do not parse webhook JSON before verification.
app.use("/api/payments/safepay/webhook", express.raw({ type: "application/json", limit: "256kb" }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const checkoutLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });

const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(254).transform(v => v.toLowerCase()),
  phone: z.string().trim().min(7).max(30).optional(),
  password: z.string().min(12).max(128)
});
const loginSchema = z.object({
  email: z.string().trim().email().transform(v => v.toLowerCase()),
  password: z.string().min(1).max(128)
});
const productSchema = z.object({
  name: z.string().trim().min(2).max(160),
  slug: z.string().trim().min(2).max(180).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  description: z.string().max(5000).optional(),
  category: z.string().trim().min(1).max(80).optional(),
  imageUrl: z.string().url().max(2000).optional().or(z.literal("")),
  pricePaisa: z.number().int().positive().max(100000000),
  stock: z.number().int().min(0).max(1000000),
  active: z.boolean().optional()
});
const orderSchema = z.object({
  items: z.array(z.object({ productId: z.string().min(1), quantity: z.number().int().min(1).max(50) })).min(1).max(30),
  paymentMethod: z.enum(["COD", "SAFEPAY"]),
  customerName: z.string().trim().min(2).max(100),
  customerPhone: z.string().trim().min(7).max(30),
  shippingAddress: z.string().trim().min(8).max(500),
  city: z.string().trim().min(2).max(100),
  notes: z.string().trim().max(500).optional()
});

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "Bunny Brand BB" }));

app.post("/api/auth/register", authLimiter, async (req, res, next) => {
  try {
    const input = registerSchema.parse(req.body);
    const passwordHash = await bcrypt.hash(input.password, 12);
    const user = await prisma.user.create({ data: { ...input, passwordHash, role: "CUSTOMER" }, select: { id: true, name: true, email: true, role: true } });
    res.cookie("bb_session", signSession(user), cookieOptions());
    res.status(201).json({ user });
  } catch (e) {
    if (e?.code === "P2002") return res.status(409).json({ error: "An account with this email already exists." });
    next(e);
  }
});

app.post("/api/auth/login", authLimiter, async (req, res, next) => {
  try {
    const input = loginSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { email: input.email } });
    if (!user || !(await bcrypt.compare(input.password, user.passwordHash))) {
      return res.status(401).json({ error: "Email or password is incorrect." });
    }
    res.cookie("bb_session", signSession(user), cookieOptions());
    res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { next(e); }
});

app.post("/api/auth/logout", (_req, res) => {
  res.clearCookie("bb_session", { ...cookieOptions(), maxAge: undefined });
  res.status(204).end();
});

app.get("/api/auth/me", requireAuth, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.auth.sub }, select: { id: true, name: true, email: true, phone: true, role: true } });
    if (!user) return res.status(401).json({ error: "Account not found." });
    res.json({ user });
  } catch (e) { next(e); }
});

app.get("/api/products", async (req, res, next) => {
  try {
    const where = { active: true };
    if (typeof req.query.category === "string" && req.query.category.length <= 80) where.category = req.query.category;
    if (typeof req.query.q === "string" && req.query.q.length <= 100) {
      where.OR = [
        { name: { contains: req.query.q, mode: "insensitive" } },
        { description: { contains: req.query.q, mode: "insensitive" } }
      ];
    }
    const products = await prisma.product.findMany({
      where, orderBy: { createdAt: "desc" }, take: 100,
      select: { id: true, name: true, slug: true, description: true, category: true, imageUrl: true, pricePaisa: true, stock: true }
    });
    res.json({ products });
  } catch (e) { next(e); }
});

app.get("/api/products/:id", async (req, res, next) => {
  try {
    const product = await prisma.product.findFirst({ where: { id: req.params.id, active: true } });
    if (!product) return res.status(404).json({ error: "Product not found." });
    res.json({ product });
  } catch (e) { next(e); }
});

app.post("/api/admin/products", requireAuth, requireAdmin, async (req, res, next) => {
  try { res.status(201).json({ product: await prisma.product.create({ data: productSchema.parse(req.body) }) }); }
  catch (e) { next(e); }
});
app.patch("/api/admin/products/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try { res.json({ product: await prisma.product.update({ where: { id: req.params.id }, data: productSchema.partial().parse(req.body) }) }); }
  catch (e) { next(e); }
});
app.delete("/api/admin/products/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    // Soft-delete so historic order items remain intact.
    await prisma.product.update({ where: { id: req.params.id }, data: { active: false } });
    res.status(204).end();
  } catch (e) { next(e); }
});

app.post("/api/orders", requireAuth, checkoutLimiter, async (req, res, next) => {
  try {
    const input = orderSchema.parse(req.body);
    const orderNumber = `BB-${new Date().toISOString().slice(0,10).replaceAll("-","")}-${randomUUID().slice(0,8).toUpperCase()}`;
    const order = await prisma.$transaction(async tx => {
      const ids = [...new Set(input.items.map(i => i.productId))];
      const products = await tx.product.findMany({ where: { id: { in: ids }, active: true } });
      if (products.length !== ids.length) {
        const err = new Error("One or more products are unavailable."); err.status = 400; throw err;
      }
      const productMap = new Map(products.map(p => [p.id, p]));
      let subtotalPaisa = 0;
      const rows = input.items.map(item => {
        const product = productMap.get(item.productId);
        if (product.stock < item.quantity) {
          const err = new Error(`Not enough stock for ${product.name}.`); err.status = 409; throw err;
        }
        const lineTotalPaisa = product.pricePaisa * item.quantity;
        subtotalPaisa += lineTotalPaisa;
        return { productId: product.id, productName: product.name, unitPricePaisa: product.pricePaisa, quantity: item.quantity, lineTotalPaisa };
      });
      // Conditional stock decrement prevents overselling under concurrent checkouts.
      for (const item of input.items) {
        const updated = await tx.product.updateMany({
          where: { id: item.productId, active: true, stock: { gte: item.quantity } },
          data: { stock: { decrement: item.quantity } }
        });
        if (updated.count !== 1) { const err = new Error("Stock changed during checkout. Please retry."); err.status = 409; throw err; }
      }
      return tx.order.create({
        data: {
          orderNumber, userId: req.auth.sub,
          paymentMethod: input.paymentMethod,
          paymentStatus: input.paymentMethod === "SAFEPAY" ? "PENDING" : "UNPAID",
          subtotalPaisa, shippingPaisa: 0, totalPaisa: subtotalPaisa,
          customerName: input.customerName, customerPhone: input.customerPhone,
          shippingAddress: input.shippingAddress, city: input.city, notes: input.notes,
          items: { create: rows }
        },
        include: { items: true }
      });
    });

    if (input.paymentMethod === "SAFEPAY") {
      try {
        const payment = await createSafepayCheckout({ amountPaisa: order.totalPaisa, orderNumber: order.orderNumber });
        const updated = await prisma.order.update({ where: { id: order.id }, data: { safepayTracker: payment.tracker } });
        return res.status(201).json({ order: updated, checkoutUrl: payment.checkoutUrl, message: "Complete payment on Safepay. Order is not paid until webhook confirmation." });
      } catch (e) {
        // Keep order pending for admin review; don't claim payment success.
        return res.status(e.status || 503).json({ orderNumber: order.orderNumber, error: e.message, paymentSetupRequired: true });
      }
    }
    res.status(201).json({ order, message: "Order placed. Payment is due on delivery." });
  } catch (e) { next(e); }
});

app.get("/api/orders/mine", requireAuth, async (req, res, next) => {
  try {
    const orders = await prisma.order.findMany({
      where: { userId: req.auth.sub }, orderBy: { createdAt: "desc" },
      include: { items: { select: { productName: true, unitPricePaisa: true, quantity: true, lineTotalPaisa: true } } }
    });
    res.json({ orders });
  } catch (e) { next(e); }
});

app.get("/api/admin/orders", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const orders = await prisma.order.findMany({
      orderBy: { createdAt: "desc" }, take: 200,
      include: { user: { select: { name: true, email: true } }, items: true }
    });
    res.json({ orders });
  } catch (e) { next(e); }
});

app.patch("/api/admin/orders/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const schema = z.object({ status: z.enum(["PENDING","CONFIRMED","PROCESSING","SHIPPED","DELIVERED","CANCELLED"]) });
    const { status } = schema.parse(req.body);
    const existing = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: "Order not found." });
    if (existing.paymentMethod === "SAFEPAY" && status === "DELIVERED" && existing.paymentStatus !== "PAID") {
      return res.status(409).json({ error: "Safepay order cannot be marked delivered until payment is verified." });
    }
    const order = await prisma.order.update({ where: { id: existing.id }, data: { status } });
    res.json({ order });
  } catch (e) { next(e); }
});

app.post("/api/payments/safepay/webhook", async (req, res, next) => {
  try {
    const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.from("");
    const signature = req.get("x-sfpy-signature") || req.get("x-safepay-signature") || "";
    if (!verifySafepayWebhook(rawBody, signature)) {
      return res.status(401).json({ error: "Webhook signature verifier is not configured or signature is invalid." });
    }
    const event = JSON.parse(rawBody.toString("utf8"));
    const eventToken = event.token;
    if (!eventToken || !event.type) return res.status(400).json({ error: "Invalid webhook event." });

    await prisma.paymentWebhookEvent.upsert({
      where: { eventToken },
      create: { eventToken, eventType: event.type, payload: event },
      update: {}
    });
    // Only process captured payment events. Verify order id and tracker/amount/currency.
    if (event.type === "payment.succeeded") {
      const data = event.data || {};
      const orderNumber = data.metadata?.order_id;
      const order = orderNumber ? await prisma.order.findUnique({ where: { orderNumber } }) : null;
      if (order && order.paymentMethod === "SAFEPAY" &&
          order.safepayTracker === data.tracker &&
          data.currency === "PKR" && Number(data.amount) === order.totalPaisa) {
        await prisma.order.update({
          where: { id: order.id },
          data: { paymentStatus: "PAID", status: "CONFIRMED" }
        });
      }
    } else if (event.type === "payment.failed") {
      const data = event.data || {};
      const orderNumber = data.metadata?.order_id;
      const order = orderNumber ? await prisma.order.findUnique({ where: { orderNumber } }) : null;
      if (order && order.paymentMethod === "SAFEPAY" && order.safepayTracker === data.tracker) {
        await prisma.order.update({ where: { id: order.id }, data: { paymentStatus: "FAILED" } });
      }
    }
    await prisma.paymentWebhookEvent.update({ where: { eventToken }, data: { processedAt: new Date() } });
    res.status(200).json({ received: true });
  } catch (e) { next(e); }
});

app.use((err, _req, res, _next) => {
  if (err instanceof z.ZodError) return res.status(400).json({ error: "Invalid request data.", details: err.issues.map(i => ({ path: i.path.join("."), message: i.message })) });
  if (err?.code === "P2002") return res.status(409).json({ error: "A record with this value already exists." });
  if (err?.code === "P2025") return res.status(404).json({ error: "Record not found." });
  const status = Number.isInteger(err.status) ? err.status : 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? "Server error." : err.message });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Bunny Brand BB API listening on port ${port}`));
