# Bunny Brand BB — Full-stack starter (Pakistan)

This is a deployable **starter project**, not a claim that a live store or payment account has already been created. It includes a mobile-responsive storefront, Express API, PostgreSQL/Prisma schema, customer authentication, role-protected admin product management, order placement, customer order history, COD and a Safepay integration scaffold.

## Included

- Responsive storefront and basic customer/admin UI in `public/index.html`
- PostgreSQL data models for customers, products, orders, line items and webhook events
- Password hashing with bcrypt, signed HTTP-only session cookie, rate limits, Helmet, input validation
- Admin-only create/update/soft-delete products and order-status management
- Server-calculated prices and stock checks; stock decrement is inside a database transaction
- COD orders and Safepay server-side payment session starter
- Dockerfile and Render deployment blueprint

## Important before production

**Safepay is not production-ready in this starter yet.** The checkout session setup is scaffolded against the official Node SDK, but checkout URL/auth-token generation and webhook signature verification must be validated against your current Safepay merchant account/docs. The webhook verifier intentionally rejects events until the exact signature header and HMAC format are implemented and tested. Do not launch paid checkout or mark payments as paid before this is done. Safepay docs: https://safepay-docs.netlify.app/build-your-integration/express-checkout/ and https://safepay-docs.netlify.app/developers/webhooks/overview/

The frontend's API and login work when the server is configured. This starter does not include password reset/email verification, CSRF token protection, shipping/courier integration, refunds, tax rules, image upload/storage, search indexing, inventory admin UI for editing products, monitoring, backups, or legal pages. Add these and get a security review before a public launch. For a public production deployment, use HTTPS, a managed PostgreSQL database, a strong random `JWT_SECRET`, `COOKIE_SECURE=true`, and set `APP_ORIGIN` to your exact HTTPS domain. Do not store secrets in source control.

## Run locally

Requires Node.js 20+ and a PostgreSQL database.

1. Extract this folder.
2. Copy `.env.example` to `.env`.
3. Fill in `DATABASE_URL`, a long random `JWT_SECRET`, `ADMIN_EMAIL`, and an `ADMIN_PASSWORD` at least 16 characters long.
4. Install and initialize:

   ```bash
   npm install
   npm run db:generate
   npm run db:push
   npm run db:seed
   npm start
   ```

5. Visit `http://localhost:3000`. Sign in using the admin email/password from `.env`.
6. Add products using the admin section. Replace seed/sample products with your real listings.

For local development, `COOKIE_SECURE=false`. In production set it to `true`.

## Online hosting (Render + PostgreSQL)

1. Create a PostgreSQL database with a provider such as Render Postgres or Neon. Copy its TLS connection string into `DATABASE_URL`.
2. Push this folder to a private GitHub repository.
3. Create a Render Web Service from the repo, using `render.yaml` or the commands in it.
4. Add all environment variables from `.env.example` in the hosting dashboard. Use `NODE_ENV=production`, `COOKIE_SECURE=true`, a 32+ character random `JWT_SECRET`, and the exact deployed HTTPS origin in `APP_ORIGIN`.
5. Run `npm run db:seed` once against the production database from a secure one-off shell/job after setting `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD`. Do not leave the seed admin password as a default.
6. Test signup/login, admin restrictions, COD order placement, stock, mobile layout, backups and restore before sharing the site.

Do not use a free ephemeral database for real customer/order data unless you understand its backup and retention limitations.

## Safepay setup

1. Create a Safepay sandbox account and obtain server secret, merchant API key and webhook HMAC secret from its dashboard.
2. Put them in hosting environment variables, never in browser JavaScript.
3. Complete and test the current SDK's hosted checkout URL/token flow in `src/safepay.js`.
4. Implement exact HMAC verification in `verifySafepayWebhook` according to Safepay's current documentation and your dashboard's signature header. Add signature test vectors.
5. Configure a public HTTPS webhook endpoint: `https://YOUR-DOMAIN/api/payments/safepay/webhook`.
6. Test succeeded, failed, repeated/retried events, amount mismatch, currency mismatch and forged signatures in sandbox. Confirm webhook payload fields match the stored order/tracker before changing status.
7. Only after Safepay approves your live merchant account and tests pass, switch to live credentials and live API/checkout hosts.

Safepay documentation:
- https://apidocs.getsafepay.com/
- https://safepay-docs.netlify.app/build-your-integration/express-checkout/
- https://safepay-docs.netlify.app/developers/webhooks/overview/

## Money

Prices are stored as integer paisa (e.g. Rs 1,299.00 = `129900`) to avoid floating point errors. The UI converts paisa to PKR for display. Confirm Safepay amount units with your merchant integration before live transactions.

## API overview

- `GET /api/health`
- `GET /api/products`, `GET /api/products/:id`
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`
- `POST /api/orders`, `GET /api/orders/mine`
- `POST /api/admin/products`, `PATCH /api/admin/products/:id`, `DELETE /api/admin/products/:id`
- `GET /api/admin/orders`, `PATCH /api/admin/orders/:id`
- `POST /api/payments/safepay/webhook`

For a real store, add automated tests and review authorization, webhook handling, CSRF, deployment migrations, observability and data-retention policies before accepting public traffic.
