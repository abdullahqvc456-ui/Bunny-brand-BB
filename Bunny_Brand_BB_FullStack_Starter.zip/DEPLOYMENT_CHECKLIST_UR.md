# Bunny Brand BB — Online launch checklist

## Abhi kya chahiye
- [ ] Domain name (for example, your own `.com` / `.pk`)
- [ ] Hosting account (Render, Railway, Fly.io, or another Node host)
- [ ] Managed PostgreSQL database and connection URL
- [ ] Private GitHub repository or another deployment method
- [ ] Long random `JWT_SECRET` and strong unique admin password
- [ ] Safepay merchant account, sandbox API key, secret key and webhook HMAC secret
- [ ] Live merchant approval from Safepay before accepting real payments

## Publish karne se pehle
- [ ] Set `APP_ORIGIN` to the exact HTTPS website origin
- [ ] Set `COOKIE_SECURE=true` and `NODE_ENV=production`
- [ ] Complete Safepay checkout URL generation and HMAC verification in `src/safepay.js`
- [ ] Configure Safepay HTTPS webhook URL `/api/payments/safepay/webhook`
- [ ] Test payment success/failure/retry and forged webhook rejection
- [ ] Test COD order, stock decrement, customer order privacy, admin-only routes
- [ ] Set up database backups, monitoring, privacy policy, terms, return/refund policy and contact details
- [ ] Remove sample products and upload accurate real product details/photos
- [ ] Perform a security review before public launch

**Important:** This package does not create a hosting account/domain, register a Safepay merchant, or deploy the site automatically. Those actions require your account and credentials. Never send passwords or API secrets in chat.
