import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password || password.length < 16) {
    throw new Error("Set ADMIN_EMAIL and ADMIN_PASSWORD (at least 16 characters) in .env before seeding.");
  }
  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.upsert({
    where: { email },
    update: { passwordHash, role: "ADMIN" },
    create: { name: "Bunny Brand Admin", email, passwordHash, role: "ADMIN" }
  });
  const examples = [
    { name: "BB Everyday Backpack", slug: "bb-everyday-backpack", description: "Everyday carry backpack. Replace this sample with your real product details.", category: "Bags", pricePaisa: 249900, stock: 20, active: true },
    { name: "BB Classic T-Shirt", slug: "bb-classic-t-shirt", description: "Comfortable everyday T-shirt. Add your own photos and sizes.", category: "Fashion", pricePaisa: 129900, stock: 40, active: true },
    { name: "BB Wireless Earbuds", slug: "bb-wireless-earbuds", description: "Sample product listing; verify specifications before selling.", category: "Electronics", pricePaisa: 399900, stock: 12, active: true }
  ];
  for (const p of examples) {
    await prisma.product.upsert({ where: { slug: p.slug }, update: {}, create: p });
  }
  console.log(`Admin account ready: ${email}. Sample products added if missing.`);
}

main().finally(() => prisma.$disconnect());
